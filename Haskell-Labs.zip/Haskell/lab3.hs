--exercitiile : 2.3 , 2.5, 2.6, 2.7
data Tree a = EmptyTree | Node a (Tree a, Tree a) deriving (Show, Read, Eq)
--cream un singur nod 
treeNode :: a -> Tree a
treeNode item = Node item (EmptyTree, EmptyTree)
--inseram noduri in arbore
treeInsert :: (Ord a) => a -> Tree a -> Tree a
treeInsert newItem EmptyTree = treeNode newItem
treeInsert newItem (Node item (left, right)) =
    if newItem < item
        then Node item (treeInsert newItem left, right)
        else Node item (left, treeInsert newItem right)
--conversie
treeToList :: Tree a -> [a]
treeToList EmptyTree = []
treeToList (Node item (left, right)) = (treeToList left) ++ [item] ++ (treeToList right)
--cautam element in arbore
treeElem :: (Ord a) => a -> Tree a -> Bool
treeElem targetItem EmptyTree = False
treeElem targetItem (Node item (left, right))
    | targetItem < item = treeElem targetItem left
    | targetItem > item = treeElem targetItem right
    | otherwise = True
--maximul in arbore
treeMax :: (Eq a) => Tree a -> a
treeMax (Node item (_, right)) =
    if right /= EmptyTree
        then treeMax right
        else item
 --stergem elementul maxim din arbore pe care il gasim cu functia treeMax si dupa aplicam functia de stergere treeDelete
treeDelete :: (Ord a) => a -> Tree a -> Tree a
treeDelete targetItem EmptyTree = EmptyTree
treeDelete targetItem (Node item (left, right))
    | targetItem < item = Node item (treeDelete targetItem left, right)
    | targetItem > item = Node item (left, treeDelete targetItem right)
    | left == EmptyTree = right
    | right == EmptyTree = left
    | otherwise = Node newItem (newLeft, right)
    where newItem = treeMax left
          newLeft = treeDelete newItem left
