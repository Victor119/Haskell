--Exercitiul 1 transform from binary to decimal

bintodec :: [Bool] -> Int
bintodec = foldr (\x y -> fromEnum x + 2*y) 0


