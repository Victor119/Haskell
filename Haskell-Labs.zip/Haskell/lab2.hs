si :: Bool -> Bool -> Bool
si False _ = False
si _ False = False
si _ _ = True

sau :: Bool -> Bool -> Bool
sau True _ = True
sau False True = True
sau False False = False

nu :: Bool -> Bool
nu True = False
nu False = True

adunarea :: Int -> Int -> Int
adunarea a b | a == 0 = b
	     | b == 0 = a
	     | a < b = adunarea (pred a) (succ b)
 	     | a > b = adunarea (succ a) (pred b) 

scaderea :: Int -> Int -> Int 
scaderea a b | a==0 && b==0 = 0 
             | b == 0 = a
	     | a == 0 = if b>a then scaderea (pred a) (pred b) else a  
	     | a > b = scaderea (pred a) (pred b)
	     | a < b && b>0 = scaderea (pred a) (pred b)

inmultirea :: Int -> Int -> Int
inmultirea a b | a==0 || b==0 = 0 
	       | a<b = inmultirea b a
	       | b>0 = adunarea (a) (inmultirea (a) (pred (scaderea b 1)))
	       	
