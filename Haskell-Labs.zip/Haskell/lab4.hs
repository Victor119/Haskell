-- Exercitiul 2.4
sumUp :: [Int] -> Int
sumUp xs = go 1 xs   
  where
    go counter  _ | counter == 0 = 0  
    go counter [] = 0
    go counter (x:xs) = x + go (counter + 1) xs

