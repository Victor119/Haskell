import System.IO
import System.Environment
import Data.Char

main7 = do
 putStrLn "What is your name?"
 name <- getLine
 putStrLn "What is your prenume?"
 prenume <- getLine
 putStrLn ("Hello, " ++ name ++ "!")
 putStrLn ("Hello, " ++ prenume ++ "!")
 if name == "" || prenume == "" then
  return ()
 else 
  main7

main8 = do
 putStrLn "What is your name?"
 name <- getLine
 putStrLn "What is your prenume?"
 prenume <- getLine
 let numeMare = map toUpper name
 let prenumeMare = map toUpper prenume
 putStrLn ("Hello, " ++ numeMare ++ "!")
 putStrLn ("Hello, " ++ prenumeMare ++ "!")
 if name == "" || prenume == "" then
  return ()
 else
  main8

-- openFile :: FilePath -> IOMode -> IO Handle
-- hGetContents :: Handle -> IO String
-- hGetLine :: Handle -> IO String
-- hClose :: Handle -> IO ()
-- getArgs :: IO [String]
-- getProgName :: IO String
-- hPutStr :: Handle -> String -> IO ()

main10 = do  
 handle <- openFile "exemplu.txt" ReadMode  
 contents <- hGetContents handle  
 putStr contents  
 hClose handle
 
main11 = do
 args <- getArgs
 file <- openFile (head args) ReadMode
 text <- hGetContents file
 print(text)
