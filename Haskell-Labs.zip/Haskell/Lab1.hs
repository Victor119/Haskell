cmmdc :: Int -> Int -> Int
cmmdc n k = if n==k then n else if n>k then cmmdc (n-k) k else cmmdc n (k-n)

fibo :: Int -> Int
fibo n = if n==1 || n==2 then 1 else fibo (n-1) + fibo (n-2)
